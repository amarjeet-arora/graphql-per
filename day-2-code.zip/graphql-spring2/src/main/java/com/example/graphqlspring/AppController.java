package com.example.graphqlspring;

import java.time.Duration;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
 

import com.model.Book;
import com.model.Rating;
import com.service.BookService;

 
@Controller
public class AppController {

	private BookService bookService;
	public AppController(BookService bookService) {
		this.bookService=bookService;
	}
	@SchemaMapping(typeName = "Query")
	 public Collection<Book> books(){
		 return bookService.getBooks();
	}
	@SchemaMapping(typeName = "Query")
	public Book bookById(@Argument Integer id) {
		return bookService.bookById(id);
		
	}
	@SchemaMapping(typeName = "Book")
	public List<Rating> ratings(Book book) {
		 return bookService.ratings(book);
		
	}
	 
}
