package com.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.model.*;

@Service
public class BookService {
	
	HashMap<Integer, Book> bookRepo= new HashMap<Integer, Book>();
	HashMap<Integer, Rating> ratingRepo= new HashMap<Integer, Rating>();
	
	public BookService() {
		bookRepo.put(1,new Book(1, "Book1", "author1", 16.14));
		bookRepo.put(2,new Book(2, "Book2", "author2", 17.14));
		bookRepo.put(3,new Book(3, "Book3", "author3", 18.14));
		bookRepo.put(4,new Book(4, "Book4", "author4", 19.14));
		
		ratingRepo.put(1, new Rating(1,1,5,"very nice book","user-1"));
		ratingRepo.put(2, new Rating(2,1,3,"very awesome book","user-1"));
		ratingRepo.put(3, new Rating(3,1,3,"nice book","user-2"));
		ratingRepo.put(4, new Rating(4,3,5,"satisfactory book","user-3"));
		ratingRepo.put(5, new Rating(5,3,1,"very awesome book","user-3"));
		
		
	}

	public List<Rating> ratings(Book book){
		return ratingRepo.values().stream().
		filter(r -> r.getBookId().equals(book.getId())).collect(Collectors.toList());
	}
	
	public Collection<Book> getBooks(){
		return bookRepo.values();
	}
	public Book bookById(Integer id) {
		return bookRepo.get(id);
	}

}
