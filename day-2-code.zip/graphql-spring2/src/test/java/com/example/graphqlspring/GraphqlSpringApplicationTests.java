package com.example.graphqlspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphqlSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
