package com.service;

import org.springframework.stereotype.Service;

import com.model.Customer;

import reactor.core.publisher.Flux;
@Service
public class CustomerService {
	private Flux<Customer> flux=Flux.just(
			Customer.create(1,"sam",20,"delhi"),
			Customer.create(2,"max",30,"pune"),
			Customer.create(3,"mohit",25,"surat"),
			Customer.create(1,"laxmi",28,"mumbai")
			);
	
	public Flux<Customer> allCustomer(){
		return flux;
	}
}
