package com.service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.model.Customer;
import com.model.CustomerOrder;

import reactor.core.publisher.Flux;

@Service
public class OrderService {
	
	
	private Map<String, List<CustomerOrder>>map= Map.of(
			"sam",List.of(
					CustomerOrder.create(UUID.randomUUID(), "sam-pro-1"),
					CustomerOrder.create(UUID.randomUUID(), "sam-pro-2")
					),
			"max",List.of(
					CustomerOrder.create(UUID.randomUUID(), "max-pro-1"),
					CustomerOrder.create(UUID.randomUUID(), "max-pro-2")
					));
		
	public Flux<CustomerOrder> ordersByCustomerName(String name){
		System.out.println("Order fetch for customer ");
		return Flux.fromIterable(map.getOrDefault(name, Collections.emptyList()));
	}

}
