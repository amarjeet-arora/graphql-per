package com.example.graphqlspring;

import java.time.Duration;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;

import com.model.Customer;
import com.model.CustomerOrder;
import com.service.CustomerService;
import com.service.OrderService;

import reactor.core.publisher.Flux;
 

 

@Controller
public class AppController {
    @Autowired
	private CustomerService customerService;
    @Autowired
    private OrderService orderService;
	 
    @SchemaMapping(typeName = "Query")
    public Flux<Customer>customers(){
    	return customerService.allCustomer();
    	
    }
    @SchemaMapping(typeName ="Customer" )
    public Flux<CustomerOrder> orders(Customer customer,@Argument Integer limit){
    	System.out.println("Order fetch for customer "+ customer.getName());
    	return orderService.ordersByCustomerName(customer.getName()).take(limit);
    }
}
