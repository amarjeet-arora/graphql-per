
import mongoose from 'mongoose'

const commentSchema= new mongoose.Schema({
    comment:{
        type:String
    },
    by:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User"
    }
   
})
mongoose.model("Comment",commentSchema)