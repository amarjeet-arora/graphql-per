import { gql } from "apollo-server";

const typeDefs = gql`
  type Query {
    users: [User]
    user(_id:ID): User
    comments:[CommentWithName]
    icomment(by:ID):[Comment]
  }

  type User {
    _id: ID
    firstName: String
    lastName: String
    email: String
    password: String
    comments:[Comment]
  }
  type Comment {
    by: String
    comment: String
    
  }
  type Token{
    token:String
  }

type CommentWithName{
  comment:String
  by: IdName
}

 type IdName{
  _id:String
  firstName:String
 }

  type Mutation{
    signup(userNew:UserInput):User,
    signin(userSignin:UserSigninInput):Token,
    createComment(comment:String):String
  }
  input UserInput{
    firstName: String
    lastName: String
    email: String,
    password:String
  }
  input UserSigninInput{
    email: String,
    password:String
  }
`;
export default typeDefs