import { users,comments } from "./fakedb.js";
 import mongoose  from "mongoose";
 import  jwt  from "jsonwebtoken";
 const User= mongoose.model("User")
 const Comment =mongoose.model("Comment")

import bcrypt from 'bcryptjs'
import { JWT_SECRET } from "./config.js";
const resolvers = {
    Query: {
      // load all the users
      users:async () => await User.find({}),
      
      user:async(_,{_id})=> await User.findOne({_id}) ,
      comments:async() => await Comment.find({}).populate("by","_id firstName"),
      icomment:async(_,{by})=> await Comment.find({by})
     
    },
    User:{
      comments:async(ur)=> await Comment.find({by:ur._id})  
    },
    Mutation:{
        signup:async(_,{userNew})=>{
         const user=await User.findOne({email:userNew.email})
         if(user){
          throw new Error("user email already exist")
         }
         const hashedPassword= await bcrypt.hash(userNew.password,12)
         const newUser=new User({
          ...userNew,
          password:hashedPassword
         })
       return  await newUser.save()

      },
      signin:async(_,{userSignin})=>{
        const user=await User.findOne({email:userSignin.email})
        if(!user){
          throw new Error('User doesnt exist with this email')
        }
        const doMatch= await bcrypt.compare(userSignin.password,user.password)
        if(!doMatch){
          throw new Error('password is invalid')
        }
        const token=jwt.sign({userId:user._id},JWT_SECRET)
        return {token}
     },
     createComment:async(_,{comment},{userId})=>{
      if(!userId) throw new Error("You Must be logged in")
      const newComment= new Comment({
    comment,
    by:userId
    })
    await newComment.save()
    return "comment saved....!"
     }
    }
  };

  export default resolvers