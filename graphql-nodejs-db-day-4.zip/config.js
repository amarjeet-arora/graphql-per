export const MONGO_URI="mongodb+srv://amar:amar123@cluster0.rle5i.mongodb.net/graphqldb?retryWrites=true&w=majority"
export const JWT_SECRET="jjyutrjkdfdf"