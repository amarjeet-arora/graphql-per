
export const users=[
    {
        id:"101",
        firstName:"suresh",
        lastName:"kumar",
        email:"suresh@mail.com",
        password:"pass@123"
    },
    {
        id:"102",
        firstName:"Manish",
        lastName:"kapoor",
        email:"manish@mail.com",
        password:"pass@1234"
    }

]

export const comments=[
    {
        comment:'good morning',
        by:"101"
    }, {
        comment:'good evening',
        by:"102"
    },
    {
        comment:'good night',
        by:"102"
    }

]