import { gql } from "apollo-server";

const typeDefs = gql`
  type Query {
    users: [User]
    user(_id:ID): User
    comments:[Comment]
    icomment(by:ID):[Comment]
  }

  type User {
    _id: ID
    firstName: String
    lastName: String
    email: String
    comments:[Comment]
  }
  type Comment {
    by: String
    comment: String
    
  }
  type Mutation{
    signup(
     userNew:UserInput
    ):User
  }
  input UserInput{
    firstName: String
    lastName: String
    email: String,
    password:String
  }
`;
export default typeDefs