import { users,comments } from "./fakedb.js";
import { randomBytes } from'crypto'
import mongoose  from "mongoose";
const User= mongoose.model("User")
import bcrypt from 'bcryptjs'
const resolvers = {
    Query: {
      users: () => users,
      
      user:(_,{_id})=> users.find(user=>user._id == _id),
      icomment:(_,{by})=> comments.filter(comment=>comment.by==by),
      comments:() => comments
    },
    User:{
      comments:(ur)=> comments.filter(comments=> comments.by == ur._id)
    },
    Mutation:{
        signup:async(_,{userNew})=>{
         const user=await User.findOne({email:userNew.email})
         if(user){
          throw new Error("user email already exist")
         }
         const hashedPassword= await bcrypt.hash(userNew.password,12)
         const newUser=new User({
          ...userNew,
          password:hashedPassword
         })
       return  await newUser.save()

      }
    }
  };

  export default resolvers