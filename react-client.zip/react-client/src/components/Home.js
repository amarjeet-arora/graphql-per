import React,{useEffect} from 'react'
 

export default function Home() {
 
  
    return (
        <div className="container">
           <p>Welcome</p>
        </div>
    )
}
